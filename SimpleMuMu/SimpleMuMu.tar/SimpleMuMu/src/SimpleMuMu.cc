 // -*- C++ -*-
//
// Package:    SimpleMuMu
// Class:      SimpleMuMu
// 
/**\class SimpleMuMu SimpleMuMu.cc SimpleLeptonLepton/SimpleMuMu/src/SimpleMuMu.cc

 Description: <one line class summary>

 Implementation:
     <Notes on implementation>
*/
//
// Original Author:  Jonathan Hollar
//         Created:  Wed Sep 20 10:08:38 BST 2006
// $Id: SimpleMuMu.cc,v 1.25 2008/08/27 07:24:38 jjhollar Exp $
//
//


// system include files
#include "DataFormats/PatCandidates/interface/Muon.h" 
#include "DataFormats/PatCandidates/interface/Jet.h" 
#include "DataFormats/PatCandidates/interface/Electron.h" 
#include "DataFormats/PatCandidates/interface/Tau.h" 
#include "DataFormats/PatCandidates/interface/Photon.h" 
#include "DataFormats/PatCandidates/interface/MET.h" 

#include "DataFormats/RecoCandidate/interface/IsoDeposit.h" 
 
#include "FWCore/ParameterSet/interface/ParameterSet.h"  
#include "DataFormats/Common/interface/Ref.h"  
 
#include "DataFormats/Common/interface/TriggerResults.h"  
#include "FWCore/Framework/interface/TriggerNames.h"  
   
#include "FWCore/Framework/interface/ESHandle.h" 
#include "SimDataFormats/HepMCProduct/interface/HepMCProduct.h" 
#include "DataFormats/JetReco/interface/CaloJetCollection.h" 
#include "DataFormats/JetReco/interface/CaloJet.h"  
#include "DataFormats/TrackReco/interface/Track.h"  
#include "DataFormats/TrackReco/interface/TrackFwd.h"  
#include "DataFormats/MuonReco/interface/Muon.h"  
#include "DataFormats/CaloTowers/interface/CaloTower.h"  
#include "DataFormats/CaloTowers/interface/CaloTowerFwd.h"   
#include "DataFormats/Candidate/interface/Candidate.h"  
#include "DataFormats/Candidate/interface/CandidateFwd.h"   
#include "DataFormats/RecoCandidate/interface/RecoChargedCandidate.h" 
#include "DataFormats/RecoCandidate/interface/RecoChargedCandidateFwd.h" 
#include "DataFormats/HepMCCandidate/interface/GenParticle.h"
#include "DataFormats/HepMCCandidate/interface/GenParticleFwd.h"

#include "SimpleMuMu/SimpleMuMu/interface/SimpleMuMu.h"

// user include files
#include <DataFormats/Common/interface/Handle.h>
#include <FWCore/Framework/interface/ESHandle.h>
#include <FWCore/MessageLogger/interface/MessageLogger.h> 
// Muons:
#include <DataFormats/TrackReco/interface/Track.h>
// Electrons
#include "DataFormats/EgammaCandidates/interface/GsfElectron.h"

// Vertexing 
#include "DataFormats/VertexReco/interface/Vertex.h" 
#include "DataFormats/VertexReco/interface/VertexFwd.h" 
#include "TrackingTools/TransientTrack/interface/TransientTrackBuilder.h" 
#include "TrackingTools/Records/interface/TransientTrackRecord.h" 
#include "TrackingTools/TransientTrack/interface/TransientTrack.h" 
#include "RecoVertex/VertexPrimitives/interface/TransientVertex.h" 
#include "RecoVertex/VertexPrimitives/interface/ConvertError.h" 
#include "SimTracker/Records/interface/TrackAssociatorRecord.h" 
#include "RecoVertex/KalmanVertexFit/interface/KalmanVertexFitter.h" 

// C++
#include <memory>
#include <vector>

#include <TFile.h>
#include <TH1D.h>
#include <TTree.h>

using namespace std;
using namespace edm;
using namespace reco;

//
// constants, enums and typedefs
//

//
// static data member definitions
//

//
// constructors and destructor
//
SimpleMuMu::SimpleMuMu(const edm::ParameterSet& pset)
{
   //now do what ever initialization is needed
  recTrackLabel      = pset.getParameter<edm::InputTag>("RecoTrackLabel");
  theGLBMuonLabel    = pset.getParameter<edm::InputTag>("MuonCollectionLabel");
  hltMuLabel         = pset.getParameter<edm::InputTag>("HLTMuonLabel");
  dimuonmode         = pset.getParameter<int>("DimuonMode");

  rootfilename       = pset.getUntrackedParameter<std::string>("outfilename","test.root");
  

  DIMUONMAX=500;
  NHLTMAX=500;

  thefile = new TFile(rootfilename.c_str(),"recreate");
  thefile->cd();
  thetree= new TTree("ntp1","ntp1");

  thetree->Branch("nDimuonCand",&nDimuonCand,"nDimuonCand/I");
  thetree->Branch("MuonCand1_px",MuonCand1_px,"MuonCand1_px[nDimuonCand]/D");
  thetree->Branch("MuonCand1_py",MuonCand1_py,"MuonCand1_py[nDimuonCand]/D");
  thetree->Branch("MuonCand1_pz",MuonCand1_pz,"MuonCand1_pz[nDimuonCand]/D");
  thetree->Branch("MuonCand1_p",MuonCand1_p,"MuonCand1_p[nDimuonCand]/D");
  thetree->Branch("MuonCand1_pt",MuonCand1_pt,"MuonCand1_pt[nDimuonCand]/D");
  thetree->Branch("MuonCand1_eta",MuonCand1_eta,"MuonCand1_eta[nDimuonCand]/D");
  thetree->Branch("MuonCand1_phi",MuonCand1_phi,"MuonCand1_phi[nDimuonCand]/D");
  thetree->Branch("MuonCand1_charge",MuonCand1_charge,"MuonCand1_charge[nDimuonCand]/I");
  thetree->Branch("MuonCand1_tmlsloosemuonid",MuonCand1_tmlsloosemuonid,"MuonCand1_tmlsloosemuonid[nDimuonCand]/I");
  thetree->Branch("MuonCand1_tm2dloosemuid",MuonCand1_tm2dloosemuid,"MuonCand1_tm2dloosemuid[nDimuonCand]/I");
  thetree->Branch("MuonCand1_arbmuid",MuonCand1_arbmuid,"MuonCand1_arbmuid[nDimuonCand]/I");
  thetree->Branch("MuonCand1_isglobal",MuonCand1_isglobal,"MuonCand1_isglobal[nDimuonCand]/I");
  thetree->Branch("MuonCand1_istracker",MuonCand1_istracker,"MuonCand1_istracker[nDimuonCand]/I"); 
  thetree->Branch("MuonCand1_isstandalone",MuonCand1_isstandalone,"MuonCand1_isstandalone[nDimuonCand]/I"); 
  thetree->Branch("MuonCand1_hcalisor3",MuonCand1_hcalisor3,"MuonCand1_hcalisor3[nDimuonCand]/D"); 
  thetree->Branch("MuonCand1_ecalisor3",MuonCand1_ecalisor3,"MuonCand1_ecalisor3[nDimuonCand]/D");  
  thetree->Branch("MuonCand1_trkisor3",MuonCand1_trkisor3,"MuonCand1_trkisor3[nDimuonCand]/D");  
  thetree->Branch("MuonCand1_hcalisor5",MuonCand1_hcalisor5,"MuonCand1_hcalisor5[nDimuonCand]/D");  
  thetree->Branch("MuonCand1_ecalisor5",MuonCand1_ecalisor5,"MuonCand1_ecalisor5[nDimuonCand]/D");  
  thetree->Branch("MuonCand1_trkisor5",MuonCand1_trkisor5,"MuonCand1_trkisor5[nDimuonCand]/D"); 
  thetree->Branch("MuonCand2_px",MuonCand2_px,"MuonCand2_px[nDimuonCand]/D");
  thetree->Branch("MuonCand2_py",MuonCand2_py,"MuonCand2_py[nDimuonCand]/D");
  thetree->Branch("MuonCand2_pz",MuonCand2_pz,"MuonCand2_pz[nDimuonCand]/D");
  thetree->Branch("MuonCand2_p",MuonCand2_p,"MuonCand2_p[nDimuonCand]/D");
  thetree->Branch("MuonCand2_pt",MuonCand2_pt,"MuonCand2_pt[nDimuonCand]/D");
  thetree->Branch("MuonCand2_eta",MuonCand2_eta,"MuonCand2_eta[nDimuonCand]/D");
  thetree->Branch("MuonCand2_phi",MuonCand2_phi,"MuonCand2_phi[nDimuonCand]/D");
  thetree->Branch("MuonCand2_charge",MuonCand2_charge,"MuonCand2_charge[nDimuonCand]/I");
  thetree->Branch("MuonCand2_tmlsloosemuonid",MuonCand2_tmlsloosemuonid,"MuonCand2_tmlsloosemuonid[nDimuonCand]/I");
  thetree->Branch("MuonCand2_tm2dloosemuid",MuonCand2_tm2dloosemuid,"MuonCand2_tm2dloosemuid[nDimuonCand]/I");
  thetree->Branch("MuonCand2_arbmuid",MuonCand2_arbmuid,"MuonCand2_arbmuid[nDimuonCand]/I");
  thetree->Branch("MuonCand2_isglobal",MuonCand2_isglobal,"MuonCand2_isglobal[nDimuonCand]/I");
  thetree->Branch("MuonCand2_istracker",MuonCand2_istracker,"MuonCand2_istracker[nDimuonCand]/I"); 
  thetree->Branch("MuonCand2_isstandalone",MuonCand2_isstandalone,"MuonCand2_isstandalone[nDimuonCand]/I"); 
  thetree->Branch("MuonCand2_hcalisor3",MuonCand2_hcalisor3,"MuonCand2_hcalisor3[nDimuonCand]/D"); 
  thetree->Branch("MuonCand2_ecalisor3",MuonCand2_ecalisor3,"MuonCand2_ecalisor3[nDimuonCand]/D");  
  thetree->Branch("MuonCand2_trkisor3",MuonCand2_trkisor3,"MuonCand2_trkisor3[nDimuonCand]/D");  
  thetree->Branch("MuonCand2_hcalisor5",MuonCand2_hcalisor5,"MuonCand2_hcalisor5[nDimuonCand]/D");  
  thetree->Branch("MuonCand2_ecalisor5",MuonCand2_ecalisor5,"MuonCand2_ecalisor5[nDimuonCand]/D");  
  thetree->Branch("MuonCand2_trkisor5",MuonCand2_trkisor5,"MuonCand2_trkisor5[nDimuonCand]/D"); 

  //  thetree->Branch("nHLTMuon",&nHLTMuon,"nHLTMuon/I");
  //  thetree->Branch("L3MuonCand_pt",L3MuonCand_pt,"L3MuonCand_pt[nHLTMuon]/D");
  //  thetree->Branch("L3MuonCand_eta",L3MuonCand_eta,"L3MuonCand_eta[nHLTMuon]/D"); 
  //  thetree->Branch("L3MuonCand_phi",L3MuonCand_phi,"L3MuonCand_phi[nHLTMuon]/D"); 
 
  
  thetree->Branch("MuMu_mass",MuMu_mass,"MuMu_mass[nDimuonCand]/D");

  //  thetree->Branch("evweight",&evweight,"evweight/D"); 
}


SimpleMuMu::~SimpleMuMu()
{
 
   // do anything here that needs to be done at desctruction time
   // (e.g. close files, deallocate resources etc.)

}


//
// member functions
//

// ------------ method called to for each event  ------------
void
SimpleMuMu::analyze(const edm::Event& event, const edm::EventSetup& iSetup)
{
  nDimuonCand=0;
  nHLTMuon=0;

 //using namespace edm;
  using reco::TrackCollection;

  // Get the trigger information from the event
  edm::Handle<edm::TriggerResults> hltResults ; 
  event.getByLabel(InputTag("TriggerResults::HLT"),hltResults) ; 
  trigNames.init(*hltResults) ; 
  //  for (unsigned int i=0; i<trigNames.size(); i++)  
  //    { 
  //    }

  //  edm::Handle<RecoChargedCandidateCollection> l3muoncollection; 
  //  event.getByLabel(hltMuLabel,l3muoncollection); 
  //  if(l3muoncollection.isValid())
  //    {
  //      const RecoChargedCandidateCollection* l3muons = l3muoncollection.product(); 
  //      RecoChargedCandidateCollection::const_iterator l3muon; 
  //
  //      for(l3muon = l3muons->begin(); l3muon != l3muons->end() && nHLTMuon<NHLTMAX; ++l3muon)
  //	{
  //	  L3MuonCand_pt[nHLTMuon]=l3muon->pt();
  //	  L3MuonCand_eta[nHLTMuon]=l3muon->eta();
  //	  L3MuonCand_phi[nHLTMuon]=l3muon->phi();
  //	  nHLTMuon++;
  //	}
  //    }

  // Get the muon collection from the event

  // PAT
  //  edm::Handle<edm::View<pat::Muon> > muons; 
  //  event.getByLabel(theGLBMuonLabel,muons); 
  //  edm::View<pat::Muon>::const_iterator muon1;
  //  edm::View<pat::Muon>::const_iterator muon2;

  // AOD
  Handle<reco::MuonCollection> muons;
  event.getByLabel(theGLBMuonLabel, muons);
  reco::MuonCollection::const_iterator muon1;
  reco::MuonCollection::const_iterator muon2;

  // Two muons
  if(dimuonmode == 1)
    {
      for (muon1 = muons->begin(); muon1 != muons->end() && nDimuonCand<DIMUONMAX; ++muon1)
	{
	  for (muon2 = muons->begin(); muon2 != muons->end() && muon2 != muon1 && nDimuonCand<DIMUONMAX; ++muon2)
	    {
	      MuonCand1_p[nDimuonCand]=muon1->p();
	      MuonCand1_px[nDimuonCand]=muon1->px();
	      MuonCand1_py[nDimuonCand]=muon1->py();
	      MuonCand1_pz[nDimuonCand]=muon1->pz();
	      MuonCand1_pt[nDimuonCand]=muon1->pt();
	      MuonCand1_eta[nDimuonCand]=muon1->eta();
	      MuonCand1_phi[nDimuonCand]=muon1->phi();
	      MuonCand1_charge[nDimuonCand]=muon1->charge();
	      MuonCand2_p[nDimuonCand]=muon2->p();
	      MuonCand2_px[nDimuonCand]=muon2->px();
	      MuonCand2_py[nDimuonCand]=muon2->py();
	      MuonCand2_pz[nDimuonCand]=muon2->pz();
	      MuonCand2_pt[nDimuonCand]=muon2->pt();
	      MuonCand2_eta[nDimuonCand]=muon2->eta();
	      MuonCand2_phi[nDimuonCand]=muon2->phi();
	      MuonCand2_charge[nDimuonCand]=muon2->charge();
	      
	      // Muon ID for CMSSW_2_1_X
	      MuonCand1_tmlsloosemuonid[nDimuonCand]=muon1->isGood(reco::Muon::TMLastStationLoose);
	      MuonCand1_tm2dloosemuid[nDimuonCand]=muon1->isGood(reco::Muon::TM2DCompatibilityLoose);
	      MuonCand1_arbmuid[nDimuonCand]=muon1->isGood(reco::Muon::AllArbitrated);
	      MuonCand1_isglobal[nDimuonCand]=muon1->isGlobalMuon();
	      MuonCand1_istracker[nDimuonCand]=muon1->isTrackerMuon(); 
	      MuonCand1_isstandalone[nDimuonCand]=muon1->isStandAloneMuon(); 
	      MuonCand2_tmlsloosemuonid[nDimuonCand]=muon2->isGood(reco::Muon::TMLastStationLoose);
	      MuonCand2_tm2dloosemuid[nDimuonCand]=muon2->isGood(reco::Muon::TM2DCompatibilityLoose);
	      MuonCand2_arbmuid[nDimuonCand]=muon2->isGood(reco::Muon::AllArbitrated);
	      MuonCand2_isglobal[nDimuonCand]=muon2->isGlobalMuon();
	      MuonCand2_istracker[nDimuonCand]=muon2->isTrackerMuon(); 
	      MuonCand2_isstandalone[nDimuonCand]=muon2->isStandAloneMuon(); 
	      
	      // Isolation for CMSSW_2_1_X
	      MuonCand1_hcalisor3[nDimuonCand]=muon1->isolationR03().hadEt; 
	      MuonCand1_ecalisor3[nDimuonCand]=muon1->isolationR03().emEt;  
	      MuonCand1_trkisor3[nDimuonCand]=muon1->isolationR03().nTracks;  
	      MuonCand1_hcalisor5[nDimuonCand]=muon1->isolationR05().hadEt;  
	      MuonCand1_ecalisor5[nDimuonCand]=muon1->isolationR05().emEt;   
	      MuonCand1_trkisor5[nDimuonCand]=muon1->isolationR05().nTracks;   
	      MuonCand2_hcalisor3[nDimuonCand]=muon2->isolationR03().hadEt; 
	      MuonCand2_ecalisor3[nDimuonCand]=muon2->isolationR03().emEt;  
	      MuonCand2_trkisor3[nDimuonCand]=muon2->isolationR03().nTracks;  
	      MuonCand2_hcalisor5[nDimuonCand]=muon2->isolationR05().hadEt;  
	      MuonCand2_ecalisor5[nDimuonCand]=muon2->isolationR05().emEt;   
	      MuonCand2_trkisor5[nDimuonCand]=muon2->isolationR05().nTracks;   

	      double mass = pow(MuonCand1_p[nDimuonCand]+MuonCand2_p[nDimuonCand],2); 
	      mass-=pow(MuonCand1_px[nDimuonCand]+MuonCand2_px[nDimuonCand],2); 
	      mass-=pow(MuonCand1_py[nDimuonCand]+MuonCand2_py[nDimuonCand],2); 
	      mass-=pow(MuonCand1_pz[nDimuonCand]+MuonCand2_pz[nDimuonCand],2); 
	      MuMu_mass[nDimuonCand] = sqrt(mass); 
 
	      nDimuonCand++;
	    }  
	}
    }

  // Get the track collection from the event 
  edm::Handle<reco::TrackCollection> recoTracks; 
  event.getByLabel(recTrackLabel, recoTracks); 
  const TrackCollection* tracks = recoTracks.product(); 
  TrackCollection::const_iterator track1; 
  TrackCollection::const_iterator track2; 

  // One muon + one track
  if(dimuonmode == 2)
    {
      for (muon1 = muons->begin(); muon1 != muons->end() && nDimuonCand<DIMUONMAX; ++muon1) 
        { 
	  for (track2 = tracks->begin(); track2 != tracks->end() && (track2->p() != muon1->p()) && nDimuonCand<DIMUONMAX; ++track2) 
	    { 
	      MuonCand1_p[nDimuonCand]=muon1->p(); 
	      MuonCand1_px[nDimuonCand]=muon1->px(); 
	      MuonCand1_py[nDimuonCand]=muon1->py(); 
	      MuonCand1_pz[nDimuonCand]=muon1->pz(); 
	      MuonCand1_pt[nDimuonCand]=muon1->pt(); 
	      MuonCand1_eta[nDimuonCand]=muon1->eta(); 
	      MuonCand1_phi[nDimuonCand]=muon1->phi(); 
	      MuonCand1_charge[nDimuonCand]=muon1->charge(); 

              // Muon ID for CMSSW_2_1_X 
              MuonCand1_tmlsloosemuonid[nDimuonCand]=muon1->isGood(reco::Muon::TMLastStationLoose); 
              MuonCand1_tm2dloosemuid[nDimuonCand]=muon1->isGood(reco::Muon::TM2DCompatibilityLoose); 
              MuonCand1_arbmuid[nDimuonCand]=muon1->isGood(reco::Muon::AllArbitrated); 
              MuonCand1_isglobal[nDimuonCand]=muon1->isGlobalMuon(); 
              MuonCand1_istracker[nDimuonCand]=muon1->isTrackerMuon();  
              MuonCand1_isstandalone[nDimuonCand]=muon1->isStandAloneMuon();  

              // Isolation for CMSSW_2_1_X 
              MuonCand1_hcalisor3[nDimuonCand]=muon1->isolationR03().hadEt;  
              MuonCand1_ecalisor3[nDimuonCand]=muon1->isolationR03().emEt;   
              MuonCand1_trkisor3[nDimuonCand]=muon1->isolationR03().nTracks;   
              MuonCand1_hcalisor5[nDimuonCand]=muon1->isolationR05().hadEt;   
              MuonCand1_ecalisor5[nDimuonCand]=muon1->isolationR05().emEt;    
              MuonCand1_trkisor5[nDimuonCand]=muon1->isolationR05().nTracks;    

              MuonCand2_p[nDimuonCand]=track2->p(); 
              MuonCand2_px[nDimuonCand]=track2->px(); 
              MuonCand2_py[nDimuonCand]=track2->py(); 
              MuonCand2_pz[nDimuonCand]=track2->pz(); 
              MuonCand2_pt[nDimuonCand]=track2->pt(); 
              MuonCand2_eta[nDimuonCand]=track2->eta(); 
              MuonCand2_phi[nDimuonCand]=track2->phi(); 
              MuonCand2_charge[nDimuonCand]=track2->charge(); 

              double mass = pow(MuonCand1_p[nDimuonCand]+MuonCand2_p[nDimuonCand],2);  
              mass-=pow(MuonCand1_px[nDimuonCand]+MuonCand2_px[nDimuonCand],2);  
              mass-=pow(MuonCand1_py[nDimuonCand]+MuonCand2_py[nDimuonCand],2);  
              mass-=pow(MuonCand1_pz[nDimuonCand]+MuonCand2_pz[nDimuonCand],2);  
              MuMu_mass[nDimuonCand] = sqrt(mass);  
  
              nDimuonCand++; 

	    }
	}
    }

  // track + track
  if(dimuonmode == 3)
    {
      for (track1 = tracks->begin(); track1 != tracks->end() && nDimuonCand<DIMUONMAX; ++track1) 
	for (track2 = tracks->begin(); track2 != tracks->end() && (track1 != track2) && nDimuonCand<DIMUONMAX; ++track2) 
	    { 

              MuonCand1_p[nDimuonCand]=track1->p(); 
              MuonCand1_px[nDimuonCand]=track1->px(); 
              MuonCand1_py[nDimuonCand]=track1->py(); 
              MuonCand1_pz[nDimuonCand]=track1->pz(); 
              MuonCand1_pt[nDimuonCand]=track1->pt(); 
              MuonCand1_eta[nDimuonCand]=track1->eta(); 
              MuonCand1_phi[nDimuonCand]=track1->phi(); 
              MuonCand1_charge[nDimuonCand]=track1->charge(); 

              MuonCand2_p[nDimuonCand]=track2->p(); 
              MuonCand2_px[nDimuonCand]=track2->px(); 
              MuonCand2_py[nDimuonCand]=track2->py(); 
              MuonCand2_pz[nDimuonCand]=track2->pz(); 
              MuonCand2_pt[nDimuonCand]=track2->pt(); 
              MuonCand2_eta[nDimuonCand]=track2->eta(); 
              MuonCand2_phi[nDimuonCand]=track2->phi(); 
              MuonCand2_charge[nDimuonCand]=track2->charge(); 

	      double mass = pow(MuonCand1_p[nDimuonCand]+MuonCand2_p[nDimuonCand],2);  
	      mass-=pow(MuonCand1_px[nDimuonCand]+MuonCand2_px[nDimuonCand],2);  
	      mass-=pow(MuonCand1_py[nDimuonCand]+MuonCand2_py[nDimuonCand],2);  
	      mass-=pow(MuonCand1_pz[nDimuonCand]+MuonCand2_pz[nDimuonCand],2);  
	      MuMu_mass[nDimuonCand] = sqrt(mass);  
	      
	      nDimuonCand++; 
	    }
    }

  // Single muon
  if(dimuonmode == 4)
    {
      for (muon1 = muons->begin(); muon1 != muons->end() && nDimuonCand<DIMUONMAX; ++muon1)  
        {  
	  MuonCand1_p[nDimuonCand]=muon1->p();  
	  MuonCand1_px[nDimuonCand]=muon1->px();  
	  MuonCand1_py[nDimuonCand]=muon1->py();  
	  MuonCand1_pz[nDimuonCand]=muon1->pz();  
	  MuonCand1_pt[nDimuonCand]=muon1->pt();  
	  MuonCand1_eta[nDimuonCand]=muon1->eta();  
	  MuonCand1_phi[nDimuonCand]=muon1->phi();  
	  MuonCand1_charge[nDimuonCand]=muon1->charge();  
	  
	  // Muon ID for CMSSW_2_1_X  
	  MuonCand1_tmlsloosemuonid[nDimuonCand]=muon1->isGood(reco::Muon::TMLastStationLoose);  
	  MuonCand1_tm2dloosemuid[nDimuonCand]=muon1->isGood(reco::Muon::TM2DCompatibilityLoose);  
	  MuonCand1_arbmuid[nDimuonCand]=muon1->isGood(reco::Muon::AllArbitrated);  
	  MuonCand1_isglobal[nDimuonCand]=muon1->isGlobalMuon();  
	  MuonCand1_istracker[nDimuonCand]=muon1->isTrackerMuon();   
	  MuonCand1_isstandalone[nDimuonCand]=muon1->isStandAloneMuon();   
	  
	  // Isolation for CMSSW_2_1_X  
	  MuonCand1_hcalisor3[nDimuonCand]=muon1->isolationR03().hadEt;   
	  MuonCand1_ecalisor3[nDimuonCand]=muon1->isolationR03().emEt;    
	  MuonCand1_trkisor3[nDimuonCand]=muon1->isolationR03().nTracks;    
	  MuonCand1_hcalisor5[nDimuonCand]=muon1->isolationR05().hadEt;    
	  MuonCand1_ecalisor5[nDimuonCand]=muon1->isolationR05().emEt;     
	  MuonCand1_trkisor5[nDimuonCand]=muon1->isolationR05().nTracks;     

	  nDimuonCand++;
	}
    }

  thetree->Fill();
}


// ------------ method called once each job just before starting event loop  ------------
void 
SimpleMuMu::beginJob(const edm::EventSetup&)
{
}

// ------------ method called once each job just after ending the event loop  ------------
void 
SimpleMuMu::endJob() {
  thefile->Write();
  thefile->Close();
}
  

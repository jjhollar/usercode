import FWCore.ParameterSet.Config as cms

simplemumuanalysis = cms.EDFilter("SimpleMuMu",
                                  outfilename = cms.untracked.string('simple.mumu.root'),
                                  #    MuonCollectionLabel = cms.InputTag("selectedLayer1Muons"),
                                  MuonCollectionLabel = cms.InputTag("muons"),
                                  RecoTrackLabel = cms.InputTag("generalTracks"),
                                  HLTMuonLabel = cms.InputTag("hltL3MuonCandidates"),
                                  DimuonMode = cms.int32(2)
                                  )




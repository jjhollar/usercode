#ifndef SimpleMuMu_SimpleMuMu
#define SimpleMuMu_SimpleMuMu

// user include files
#include <FWCore/Framework/interface/Frameworkfwd.h>
#include <FWCore/Framework/interface/EDAnalyzer.h>
#include <FWCore/Framework/interface/EDFilter.h>
#include <FWCore/ParameterSet/interface/ParameterSet.h>
#include <FWCore/Framework/interface/Event.h>
#include "FWCore/ParameterSet/interface/InputTag.h"

#include "DataFormats/Common/interface/TriggerResults.h" 
#include "FWCore/Framework/interface/TriggerNames.h" 

#include <TFile.h>
#include <TH1D.h>
#include <TTree.h>

class SimpleMuMu : public edm::EDAnalyzer {
 public:
  explicit SimpleMuMu(const edm::ParameterSet&);
  ~SimpleMuMu();
  
  
 private:
  virtual void beginJob(const edm::EventSetup&) ;
  virtual void analyze(const edm::Event&, const edm::EventSetup&);
  virtual void endJob() ;
  
  // ----------member data ---------------------------
  
  edm::InputTag recTrackLabel;
  edm::InputTag theGLBMuonLabel;
  edm::InputTag hltMuLabel;

  int dimuonmode;

  std::string rootfilename;

  TFile *thefile;
  TTree *thetree;

  int nDimuonCand;
  int nHLTMuon;
  int DIMUONMAX;// used to set maximum of arrays
  int NHLTMAX;

  double MuonCand1_px[500];
  double MuonCand1_py[500];
  double MuonCand1_pz[500];
  double MuonCand1_p[500];
  double MuonCand1_eta[500];
  double MuonCand1_pt[500];
  double MuonCand1_phi[500];
  double MuonCand1_e[500];
  double MuonCandTrack1_p[500];
  int MuonCand1_charge[500];
  int MuonCand1_tmlsloosemuonid[500];
  int MuonCand1_tm2dloosemuid[500];
  int MuonCand1_arbmuid[500];
  int MuonCand1_isglobal[500];
  int MuonCand1_istracker[500];
  int MuonCand1_isstandalone[500];
  double MuonCand1_ecalisor3[500]; 
  double MuonCand1_hcalisor3[500]; 
  double MuonCand1_trkisor3[500]; 
  double MuonCand1_ecalisor5[500];  
  double MuonCand1_hcalisor5[500];  
  double MuonCand1_trkisor5[500]; 

  double MuonCand2_px[500];
  double MuonCand2_py[500];
  double MuonCand2_pz[500];
  double MuonCand2_p[500];
  double MuonCand2_eta[500];
  double MuonCand2_pt[500];
  double MuonCand2_phi[500];
  double MuonCand2_e[500];
  double MuonCandTrack2_p[500];
  int MuonCand2_charge[500];
  int MuonCand2_tmlsloosemuonid[500];
  int MuonCand2_tm2dloosemuid[500];
  int MuonCand2_arbmuid[500];
  int MuonCand2_isglobal[500];
  int MuonCand2_istracker[500];
  int MuonCand2_isstandalone[500];
  double MuonCand2_ecalisor3[500]; 
  double MuonCand2_hcalisor3[500]; 
  double MuonCand2_trkisor3[500]; 
  double MuonCand2_ecalisor5[500];  
  double MuonCand2_hcalisor5[500];  
  double MuonCand2_trkisor5[500]; 

  double MuMu_mass[500];

  double L3MuonCand_pt[500];
  double L3MuonCand_eta[500];
  double L3MuonCand_phi[500];

  edm::TriggerNames trigNames ;
};
#endif

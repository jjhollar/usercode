#include "FWCore/PluginManager/interface/ModuleDef.h"
#include "FWCore/Framework/interface/MakerMacros.h"

#include "SimpleMuMu/SimpleMuMu/interface/SimpleMuMu.h"

DEFINE_SEAL_MODULE();
DEFINE_FWK_MODULE(SimpleMuMu);
